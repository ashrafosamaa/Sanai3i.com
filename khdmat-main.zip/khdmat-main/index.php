<?php
header("LOCATION:/khdmat/user/");
?>