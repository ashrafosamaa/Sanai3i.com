
  <!-- Vendor JS Files -->
  <script src="/khdmat/assets/vendor/purecounter/purecounter.js"></script>
  <script src="/khdmat/assets/vendor/aos/aos.js"></script>
  <script src="/khdmat/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="/khdmat/assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="/khdmat/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="/khdmat/assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!--  Main JS File -->
  <script src="/khdmat/assets/js/main.js"></script>

</body>

</html>