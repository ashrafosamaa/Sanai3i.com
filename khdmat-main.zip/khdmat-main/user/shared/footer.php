  <!-- ======= Footer ======= -->
  <footer id="footer" class="section-bg">
    <div class="footer-top" >
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="row">
              <div class="col-sm-6">
                <div class="footer-info">
                  <h3>Sanai3i</h3>
                </div>
                <div class="footer-newsletter">
                <p>
                Its main goal is to provide technicians in all professions at affordable prices for all members of the group. Electricians, plumbers, maintenance technicians, refrigerators, washing machines, air conditioners, heaters, stoves, discussion, upholsterers.
                </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6">
                <div class="footer-links">
                  <p>
                    <strong>Addres: </strong>Qalyubia / Egypt<br>
                    <strong>Phone: </strong> +20 105 060 9664<br>
                    <strong>E-mail: </strong>mohamedabdelstar30@gmail.com<br>
                  </p>
                </div>
                <div class="social-links">
                  <a href="https://www.instagram.com/mohammed_abdel_satar/"><i class="bi bi-twitter"></i></a>
                  <a href="https://www.facebook.com/mohamed.a.abdelstar.9" class="facebook"><i class="bi bi-facebook"></i></a>
                  <a href="https://www.instagram.com/mohammed_abdel_satar/" class="instagram"><i class="bi bi-instagram"></i></a>
                  <a href="https://www.linkedin.com/in/abdelsatar5060/" class="linkedin"><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
        </div>
      </div>
    </div>

  </footer><!-- End  Footer -->