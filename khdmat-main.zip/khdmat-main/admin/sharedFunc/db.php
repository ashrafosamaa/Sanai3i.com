<?php

$host = "localhost";
$user = 'root';
$password = "";
$dbName = "khdmate";
$conn = mysqli_connect($host, $user, $password, $dbName);