
  <!-- Vendor JS Files -->
  <script src="/khdmat/admin/assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="/khdmat/admin/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="/khdmat/admin/assets/vendor/chart.js/chart.min.js"></script>
  <script src="/khdmat/admin/assets/vendor/echarts/echarts.min.js"></script>
  <script src="/khdmat/admin/assets/vendor/quill/quill.min.js"></script>
  <script src="/khdmat/admin/assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="/khdmat/admin/assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="/khdmat/admin/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="/khdmat/admin/assets/js/main.js"></script>

</body>

</html>
