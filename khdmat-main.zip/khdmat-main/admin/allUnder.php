<?php
include './shared/script.php';
