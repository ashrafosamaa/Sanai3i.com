<?php
include 'allHead.php';
include './sharedFunc/func.php';

?>
<main id="main" class="main">

  <div class="pagetitle">

  </div><!-- End Page Title -->

  <section class="section dashboard">
    <div class="row">

      <img src="icon.jpg" width="100" height="500">
    </div><!-- End Right side columns -->

  </section>

</main><!-- End #main -->

<?php
include 'allUnder.php';
?>